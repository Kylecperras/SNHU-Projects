#include "TableFormatting.h"

using namespace std;

// Displays header for the store
void TableHeader() {
    cout << "###########################################################" << endl;
    cout << ":              WELCOME TO CORNER GROCER STORE             :" << endl;
    cout << ":---------------------------------------------------------:" << endl;
    cout << ":          Proud partner of Chada Tech Solutions          :" << endl;
    cout << "###########################################################" << endl;
    cout << endl;
}

// Displays menu options for user
void MenuDisplay() {
    cout << "+---------------------------------------------------------+" << endl;
    cout << "|                Inventory Options                        |" << endl;
    cout << "+-----+---------------------------------------------------+" << endl;
    cout << "|  1  |      Search by Item Name                          |" << endl;
    cout << "+-----+---------------------------------------------------+" << endl;
    cout << "|  2  |      List Inventory and Quantity                  |" << endl;
    cout << "+-----+---------------------------------------------------+" << endl;
    cout << "|  3  |      List Inventory and Quantity (Histogram)      |" << endl;
    cout << "+-----+---------------------------------------------------+" << endl;
    cout << "|  4  |      Quit Program                                 |" << endl;
    cout << "+-----+---------------------------------------------------+" << endl;
}