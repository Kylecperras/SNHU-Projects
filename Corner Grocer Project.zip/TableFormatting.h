#ifndef PROJECTS_GROCERCORNER_TABLEFORMATTING_H
#define PROJECTS_GROCERCORNER_TABLEFORMATTING_H
#include "MenuOptions.h"

// Displays header for the store
void TableHeader();

// Displays menu options for user
void MenuDisplay();

#endif