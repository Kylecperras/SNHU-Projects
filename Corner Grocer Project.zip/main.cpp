/*
* Kyle Perras - Programming Languages  - 04/14/2023
*/

#include "TableFormatting.h"
using namespace std;

int main() {
	string inFileName = "Project_Three_Input_File.txt";				// Modifiable file to read input from
	string outFileName = "frequency.dat";							// Modifiable name for backup of items and associated quantity
	ItemStock CornerGrocer;
	
	// Main function
	CornerGrocer.BodyFunction(inFileName, outFileName);				
}