#ifndef PROJECTS_GROCERCORNER_MENUOPTIONS_H
#define PROJECTS_GROCERCORNER_MENUOPTIONS_H
#include <iostream>
#include <string>
#include <vector>
#include <map>

using namespace std;

// Class to handle store inventory and convey data
class ItemStock {
public:
	void SetItemsAndQuantity(string fileName);
	void WriteBackup(string fileName);
	void PrintItems();
	void ItemSearch();
	void DisplayInventory();
	void DisplayHistogram();

	void BodyFunction(string inFile, string outFile);

private:
	vector<string> itemVector;
	map<string, int> itemMap;
};

#endif 
