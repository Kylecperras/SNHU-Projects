#include "MenuOptions.h"
#include <fstream>
#include <iomanip>
#include "TableFormatting.h"

// Opens file and creates key value pairs of the item and its quantity
void ItemStock::SetItemsAndQuantity(string fileName) {
	ifstream inFileStream;
	string itemName;
	
	// Attempt to open the file for use
	inFileStream.open(fileName);

	// If the file fails to open, notify user
	if (!inFileStream.is_open()) {
		cout << "Failed to open " << fileName << "." << endl;
	}

	// Read item name to key and iterate value for duplicate keys
	while (inFileStream.good()) {
		getline(inFileStream, itemName);
		if (itemMap.count(itemName) == 0) {
			itemMap.emplace(itemName, 1);
		}
		else {
			itemMap[itemName]++;
		}
	}

	// Set map keys to variable and store in vector
	for (auto itemKey : itemMap) {											// Researched more into map class to find how to access a specific key.
		itemVector.push_back(itemKey.first);									// Adds item name to list of stocked items
	}


	if (!inFileStream.eof()) {
		cout << "Failed to read all input from file." << endl;
	}

	// Close file after reading input to vector
	inFileStream.close();
}

// Prints the items available at the store for lookup
void ItemStock::PrintItems() {
	for (int i = 0; i < itemVector.size(); i++) {
		cout << "     > " << itemVector.at(i) << endl;
		cout << endl;
	}
	cout << endl;
}

// Allows user to search by keyword to return the number of items in stock
void ItemStock::ItemSearch() {
	string userInput;
	bool validInput;

	cout << "Enter an item from the list below:" << endl;

	PrintItems();

	cout << "Item Name: ";
	cin >> userInput;
	cout << endl;

	validInput = false;

	// Input validation for item name
	while (!validInput) {
		for (int i = 0; i < itemVector.size(); i++) {
			if (userInput != itemVector.at(i)) {
				continue;
			}
			else {
				validInput = true;
				break;
			}
		}
		if (validInput == false) {
			cout << "You must enter an item on this list." << endl;
			PrintItems();
			cout << "Enter item name: ";
			cin >> userInput;
			cout << endl;
			
		}
		else {
			break;
		}
	}
	cout << "********************************" << endl;
	cout << "  There are " << itemMap.at(userInput) << " " << userInput << " in stock.  " << endl;
	cout << endl;
	cout << "********************************" << endl;
	cout << endl;
}

// Displays key value pairs of items and quantity
void ItemStock::DisplayInventory() {
	cout << "############################################################" << endl;
	cout << "#        Item Name            |         Quantity           #" << endl;
	cout << "############################################################" << endl;

	for (int i = 0; i < itemVector.size(); i++) {
		cout << "|" << setw(16) << itemVector.at(i) << setw(14) << "|" << setw(14) << itemMap[itemVector.at(i)] << setw(15) << "|" << endl;
		cout << "+----------------------------------------------------------+" << endl;
		cout << setfill(' ');
	}
	cout << endl;
	cout << endl;
}

// Displays key value pairs of items and quantity as a histogram
void ItemStock::DisplayHistogram() {
	cout << "############################################################" << endl;
	cout << "#   Item Name   | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10+  #" << endl;
	cout << "############################################################" << endl;
	for (int i = 0; i < itemVector.size(); i++) {
		cout << setw(12) << itemVector.at(i) << "   ";
		for (int j = 0; j < itemMap[itemVector.at(i)]; j++) {
			cout << setw(4) << "X";
		}
		cout << endl;
		cout << "-----------------------------------------------------------" << endl;
	}
	cout << endl;
	cout << endl;
}

// Creates a backup file of key value pairs
void ItemStock::WriteBackup(string fileName) {
	ofstream outFileStream;

	outFileStream.open(fileName);

	if (!outFileStream.is_open()) {
		cout << "Unable to open " << fileName << "." << endl;
	}
	else {
		for (auto mapPair : itemMap) {
			outFileStream << mapPair.first << " " << mapPair.second << endl;
		}
	}
	outFileStream.close();
}

// Combines everthing to keep Main clean 
void ItemStock::BodyFunction(string inFile, string outFile) {
	int userInput;

	// Creates a backup .dat file 
	WriteBackup(outFile);

	// Reads data from file and maps item to quantity
	SetItemsAndQuantity(inFile);

	// Prints a table header
	TableHeader();

	// Print user menu for selection
	MenuDisplay();
	cout << endl;
	cout << "Option: ";
	cin >> userInput;
	cout << endl;

	// Switch to output info based on user input
	while (userInput != 4) {
		switch (userInput) {
		case 1:
			ItemSearch();							// Search for item by keyword
			break;
		case 2:
			DisplayInventory();					// Display items and associated quantities
			break;
		case 3:
			DisplayHistogram();					// Displays items and quantities as a histogram
			break;
		}

		// Repeats until user quits
		cout << "Please enter another number or press four (4) to quit." << endl;

		MenuDisplay();

		cout << "Option: ";
		cin >> userInput;
		cout << endl;
	}

	// Inform user that program is closing
	cout << "***** Exiting Program *****" << endl;
	cout << "Thank you for using Chada Tech." << endl;
	cout << endl;
}